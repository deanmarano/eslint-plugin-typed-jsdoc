import{l as o,b as r}from"../chunks/CIAy1Z3m.js";export{o as load_css,r as start};
